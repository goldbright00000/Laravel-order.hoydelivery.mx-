<?php

return [
    'name' => 'SuperCache'
];
